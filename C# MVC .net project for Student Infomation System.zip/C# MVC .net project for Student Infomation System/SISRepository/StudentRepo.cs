﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SIS.Models;
using Dapper;
using System.Data.SqlClient;

namespace SISRepository
{
    public class StudentRepo
    {   // This is the connection string represents database name and database engine server name  
        readonly string connectionString = "Data Source=DESKTOP-BT9QMO1\\SQLEXPRESS;Initial Catalog=StudentDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        private IDbConnection conn { get; set; }

        // creating a constructor to make sure IDb has vaild connection string  
        public StudentRepo()

        // this method call the connection string save in a variable conn 
        {
            conn = new SqlConnection(connectionString);
        }
        public void AddStudent(Student sdnt)
        // here the insertion function to add new student to the database
        {
            this.conn.Execute("InsertStudent",sdnt,commandType:CommandType.StoredProcedure);
        }
        public List<Student> GetAllStudent()

        {
            return this.conn.Query<Student>("GetAllStudent",commandType:CommandType.StoredProcedure).ToList();
        }
     }
}
