﻿namespace SIS.MainAPP
{
    partial class Student
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label7 = new System.Windows.Forms.Label();
            this.richTextBoxAddress = new System.Windows.Forms.RichTextBox();
            this.textBoxContact_num = new System.Windows.Forms.TextBox();
            this.textBoxfirst_name = new System.Windows.Forms.TextBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelDOB = new System.Windows.Forms.Label();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxdob = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridViewStudent = new System.Windows.Forms.DataGridView();
            this.menuStripSIS = new System.Windows.Forms.MenuStrip();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departmentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addGradeToStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editDeleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllStudentGradeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTeacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignTeacherToCourseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editRemoveTeacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCorseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editDeleteCourseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageCourseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editRemoveStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDepartmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.assignCourseToDepartmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageDepartmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.exitApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).BeginInit();
            this.menuStripSIS.SuspendLayout();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Yu Gothic UI", 20.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(221, -99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(242, 38);
            this.label7.TabIndex = 33;
            this.label7.Text = "Add New Student";
            // 
            // richTextBoxAddress
            // 
            this.richTextBoxAddress.Location = new System.Drawing.Point(108, 249);
            this.richTextBoxAddress.Name = "richTextBoxAddress";
            this.richTextBoxAddress.Size = new System.Drawing.Size(215, 92);
            this.richTextBoxAddress.TabIndex = 31;
            this.richTextBoxAddress.Text = "";
            // 
            // textBoxContact_num
            // 
            this.textBoxContact_num.Location = new System.Drawing.Point(108, 194);
            this.textBoxContact_num.Name = "textBoxContact_num";
            this.textBoxContact_num.Size = new System.Drawing.Size(215, 23);
            this.textBoxContact_num.TabIndex = 30;
            // 
            // textBoxfirst_name
            // 
            this.textBoxfirst_name.Location = new System.Drawing.Point(380, -37);
            this.textBoxfirst_name.Name = "textBoxfirst_name";
            this.textBoxfirst_name.Size = new System.Drawing.Size(200, 23);
            this.textBoxfirst_name.TabIndex = 28;
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCancel.Location = new System.Drawing.Point(83, 381);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(111, 38);
            this.buttonCancel.TabIndex = 26;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = false;
            // 
            // buttonAdd
            // 
            this.buttonAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonAdd.Location = new System.Drawing.Point(212, 381);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(111, 38);
            this.buttonAdd.TabIndex = 25;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = false;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 15);
            this.label5.TabIndex = 23;
            this.label5.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 22;
            this.label4.Text = "Contact No";
            // 
            // labelDOB
            // 
            this.labelDOB.AutoSize = true;
            this.labelDOB.Location = new System.Drawing.Point(12, 142);
            this.labelDOB.Name = "labelDOB";
            this.labelDOB.Size = new System.Drawing.Size(31, 15);
            this.labelDOB.TabIndex = 21;
            this.labelDOB.Text = "DOB";
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Location = new System.Drawing.Point(221, -37);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(64, 15);
            this.labelFirstName.TabIndex = 18;
            this.labelFirstName.Text = "First Name";
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Location = new System.Drawing.Point(108, 96);
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(215, 23);
            this.textBoxLastName.TabIndex = 39;
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Location = new System.Drawing.Point(108, 51);
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(215, 23);
            this.textBoxFirstName.TabIndex = 38;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 15);
            this.label3.TabIndex = 36;
            this.label3.Text = "First Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxdob);
            this.groupBox1.Controls.Add(this.textBoxFirstName);
            this.groupBox1.Controls.Add(this.textBoxLastName);
            this.groupBox1.Controls.Add(this.labelDOB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.buttonAdd);
            this.groupBox1.Controls.Add(this.buttonCancel);
            this.groupBox1.Controls.Add(this.textBoxContact_num);
            this.groupBox1.Controls.Add(this.richTextBoxAddress);
            this.groupBox1.Location = new System.Drawing.Point(21, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(379, 455);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "AddStudent ";
            // 
            // textBoxdob
            // 
            this.textBoxdob.Location = new System.Drawing.Point(108, 134);
            this.textBoxdob.Name = "textBoxdob";
            this.textBoxdob.Size = new System.Drawing.Size(215, 23);
            this.textBoxdob.TabIndex = 41;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.dataGridViewStudent);
            this.groupBox2.Location = new System.Drawing.Point(400, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(535, 477);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Student List";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Simple Student Information System";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SIS.MainAPP.Properties.Resources.Regent_logo_Login;
            this.pictureBox1.Location = new System.Drawing.Point(6, 257);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(364, 220);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridViewStudent
            // 
            this.dataGridViewStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStudent.Location = new System.Drawing.Point(6, 22);
            this.dataGridViewStudent.Name = "dataGridViewStudent";
            this.dataGridViewStudent.RowTemplate.Height = 25;
            this.dataGridViewStudent.Size = new System.Drawing.Size(518, 195);
            this.dataGridViewStudent.TabIndex = 0;
            // 
            // menuStripSIS
            // 
            this.menuStripSIS.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.menuStripSIS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentToolStripMenuItem,
            this.courseToolStripMenuItem,
            this.departmentToolStripMenuItem,
            this.teacherToolStripMenuItem,
            this.departmentToolStripMenuItem1});
            this.menuStripSIS.Location = new System.Drawing.Point(0, 0);
            this.menuStripSIS.Name = "menuStripSIS";
            this.menuStripSIS.Size = new System.Drawing.Size(1021, 27);
            this.menuStripSIS.TabIndex = 43;
            this.menuStripSIS.Text = "menuStrip1";
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentToolStripMenuItem,
            this.editRemoveStudentToolStripMenuItem,
            this.manageStudentToolStripMenuItem,
            this.exitApplicationToolStripMenuItem});
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(70, 23);
            this.studentToolStripMenuItem.Text = "Student";
            // 
            // courseToolStripMenuItem
            // 
            this.courseToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.courseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewCorseToolStripMenuItem,
            this.editDeleteCourseToolStripMenuItem,
            this.manageCourseToolStripMenuItem});
            this.courseToolStripMenuItem.Name = "courseToolStripMenuItem";
            this.courseToolStripMenuItem.Size = new System.Drawing.Size(64, 23);
            this.courseToolStripMenuItem.Text = "Course";
            // 
            // departmentToolStripMenuItem
            // 
            this.departmentToolStripMenuItem.BackColor = System.Drawing.Color.Gold;
            this.departmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addGradeToStudentToolStripMenuItem,
            this.editDeleteToolStripMenuItem,
            this.viewAllStudentGradeToolStripMenuItem});
            this.departmentToolStripMenuItem.Name = "departmentToolStripMenuItem";
            this.departmentToolStripMenuItem.Size = new System.Drawing.Size(58, 23);
            this.departmentToolStripMenuItem.Text = "Grade";
            this.departmentToolStripMenuItem.Click += new System.EventHandler(this.departmentToolStripMenuItem_Click);
            // 
            // teacherToolStripMenuItem
            // 
            this.teacherToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.teacherToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTeacherToolStripMenuItem,
            this.assignTeacherToCourseToolStripMenuItem,
            this.editRemoveTeacherToolStripMenuItem});
            this.teacherToolStripMenuItem.Name = "teacherToolStripMenuItem";
            this.teacherToolStripMenuItem.Size = new System.Drawing.Size(69, 23);
            this.teacherToolStripMenuItem.Text = "Teacher";
            // 
            // departmentToolStripMenuItem1
            // 
            this.departmentToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.departmentToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDepartmentToolStripMenuItem,
            this.assignCourseToDepartmentToolStripMenuItem,
            this.manageDepartmentToolStripMenuItem});
            this.departmentToolStripMenuItem1.Name = "departmentToolStripMenuItem1";
            this.departmentToolStripMenuItem1.Size = new System.Drawing.Size(95, 23);
            this.departmentToolStripMenuItem1.Text = "Department";
            // 
            // addGradeToStudentToolStripMenuItem
            // 
            this.addGradeToStudentToolStripMenuItem.BackColor = System.Drawing.Color.Gold;
            this.addGradeToStudentToolStripMenuItem.Name = "addGradeToStudentToolStripMenuItem";
            this.addGradeToStudentToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.addGradeToStudentToolStripMenuItem.Text = "Add Grade to Student";
            this.addGradeToStudentToolStripMenuItem.Click += new System.EventHandler(this.addGradeToStudentToolStripMenuItem_Click);
            // 
            // editDeleteToolStripMenuItem
            // 
            this.editDeleteToolStripMenuItem.BackColor = System.Drawing.Color.Gold;
            this.editDeleteToolStripMenuItem.Name = "editDeleteToolStripMenuItem";
            this.editDeleteToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.editDeleteToolStripMenuItem.Text = "Edit/Delete ";
            this.editDeleteToolStripMenuItem.Click += new System.EventHandler(this.editDeleteToolStripMenuItem_Click);
            // 
            // viewAllStudentGradeToolStripMenuItem
            // 
            this.viewAllStudentGradeToolStripMenuItem.BackColor = System.Drawing.Color.Gold;
            this.viewAllStudentGradeToolStripMenuItem.Name = "viewAllStudentGradeToolStripMenuItem";
            this.viewAllStudentGradeToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.viewAllStudentGradeToolStripMenuItem.Text = "View All student Grade";
            this.viewAllStudentGradeToolStripMenuItem.Click += new System.EventHandler(this.viewAllStudentGradeToolStripMenuItem_Click);
            // 
            // addTeacherToolStripMenuItem
            // 
            this.addTeacherToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.addTeacherToolStripMenuItem.Name = "addTeacherToolStripMenuItem";
            this.addTeacherToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.addTeacherToolStripMenuItem.Text = "Add Teacher";
            this.addTeacherToolStripMenuItem.Click += new System.EventHandler(this.addTeacherToolStripMenuItem_Click);
            // 
            // assignTeacherToCourseToolStripMenuItem
            // 
            this.assignTeacherToCourseToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.assignTeacherToCourseToolStripMenuItem.Name = "assignTeacherToCourseToolStripMenuItem";
            this.assignTeacherToCourseToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.assignTeacherToCourseToolStripMenuItem.Text = "Assign Teacher to Course";
            this.assignTeacherToCourseToolStripMenuItem.Click += new System.EventHandler(this.assignTeacherToCourseToolStripMenuItem_Click);
            // 
            // editRemoveTeacherToolStripMenuItem
            // 
            this.editRemoveTeacherToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.editRemoveTeacherToolStripMenuItem.Name = "editRemoveTeacherToolStripMenuItem";
            this.editRemoveTeacherToolStripMenuItem.Size = new System.Drawing.Size(235, 24);
            this.editRemoveTeacherToolStripMenuItem.Text = "Edit/Remove Teacher";
            this.editRemoveTeacherToolStripMenuItem.Click += new System.EventHandler(this.editRemoveTeacherToolStripMenuItem_Click);
            // 
            // addNewCorseToolStripMenuItem
            // 
            this.addNewCorseToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addNewCorseToolStripMenuItem.Name = "addNewCorseToolStripMenuItem";
            this.addNewCorseToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.addNewCorseToolStripMenuItem.Text = "Add New Course";
            this.addNewCorseToolStripMenuItem.Click += new System.EventHandler(this.addNewCorseToolStripMenuItem_Click);
            // 
            // editDeleteCourseToolStripMenuItem
            // 
            this.editDeleteCourseToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.editDeleteCourseToolStripMenuItem.Name = "editDeleteCourseToolStripMenuItem";
            this.editDeleteCourseToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.editDeleteCourseToolStripMenuItem.Text = "Edit/Delete Course";
            this.editDeleteCourseToolStripMenuItem.Click += new System.EventHandler(this.editDeleteCourseToolStripMenuItem_Click);
            // 
            // manageCourseToolStripMenuItem
            // 
            this.manageCourseToolStripMenuItem.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.manageCourseToolStripMenuItem.Name = "manageCourseToolStripMenuItem";
            this.manageCourseToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.manageCourseToolStripMenuItem.Text = "Manage Course";
            this.manageCourseToolStripMenuItem.Click += new System.EventHandler(this.manageCourseToolStripMenuItem_Click);
            // 
            // addStudentToolStripMenuItem
            // 
            this.addStudentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addStudentToolStripMenuItem.Name = "addStudentToolStripMenuItem";
            this.addStudentToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.addStudentToolStripMenuItem.Text = "Add Student";
            this.addStudentToolStripMenuItem.Click += new System.EventHandler(this.addStudentToolStripMenuItem_Click);
            // 
            // editRemoveStudentToolStripMenuItem
            // 
            this.editRemoveStudentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.editRemoveStudentToolStripMenuItem.Name = "editRemoveStudentToolStripMenuItem";
            this.editRemoveStudentToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.editRemoveStudentToolStripMenuItem.Text = "Edit/Remove Student";
            this.editRemoveStudentToolStripMenuItem.Click += new System.EventHandler(this.editRemoveStudentToolStripMenuItem_Click);
            // 
            // manageStudentToolStripMenuItem
            // 
            this.manageStudentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.manageStudentToolStripMenuItem.Name = "manageStudentToolStripMenuItem";
            this.manageStudentToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.manageStudentToolStripMenuItem.Text = "Manage Student";
            this.manageStudentToolStripMenuItem.Click += new System.EventHandler(this.manageStudentToolStripMenuItem_Click);
            // 
            // addDepartmentToolStripMenuItem
            // 
            this.addDepartmentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.addDepartmentToolStripMenuItem.Name = "addDepartmentToolStripMenuItem";
            this.addDepartmentToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.addDepartmentToolStripMenuItem.Text = "Add Department";
            this.addDepartmentToolStripMenuItem.Click += new System.EventHandler(this.addDepartmentToolStripMenuItem_Click);
            // 
            // assignCourseToDepartmentToolStripMenuItem
            // 
            this.assignCourseToDepartmentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.assignCourseToDepartmentToolStripMenuItem.Name = "assignCourseToDepartmentToolStripMenuItem";
            this.assignCourseToDepartmentToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.assignCourseToDepartmentToolStripMenuItem.Text = "Assign Course to Department";
            this.assignCourseToDepartmentToolStripMenuItem.Click += new System.EventHandler(this.assignCourseToDepartmentToolStripMenuItem_Click);
            // 
            // manageDepartmentToolStripMenuItem
            // 
            this.manageDepartmentToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.manageDepartmentToolStripMenuItem.Name = "manageDepartmentToolStripMenuItem";
            this.manageDepartmentToolStripMenuItem.Size = new System.Drawing.Size(261, 24);
            this.manageDepartmentToolStripMenuItem.Text = "Manage Department";
            this.manageDepartmentToolStripMenuItem.Click += new System.EventHandler(this.manageDepartmentToolStripMenuItem_Click);
            // 
            // exitApplicationToolStripMenuItem
            // 
            this.exitApplicationToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.exitApplicationToolStripMenuItem.Name = "exitApplicationToolStripMenuItem";
            this.exitApplicationToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.exitApplicationToolStripMenuItem.Text = "Exit Application";
            this.exitApplicationToolStripMenuItem.Click += new System.EventHandler(this.exitApplicationToolStripMenuItem_Click);
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 513);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxfirst_name);
            this.Controls.Add(this.labelFirstName);
            this.Controls.Add(this.menuStripSIS);
            this.MainMenuStrip = this.menuStripSIS;
            this.Name = "Student";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).EndInit();
            this.menuStripSIS.ResumeLayout(false);
            this.menuStripSIS.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label7;
        private RichTextBox richTextBoxAddress;
        private TextBox textBoxContact_num;
        private TextBox textBoxfirst_name;
        private Button buttonCancel;
        private Button buttonAdd;
        private Label label5;
        private Label label4;
        private Label labelDOB;
        private Label labelFirstName;
        private TextBox textBoxLastName;
        private TextBox textBoxFirstName;
        private Label label2;
        private Label label3;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private DataGridView dataGridViewStudent;
        private TextBox textBoxdob;
        private Label label1;
        private PictureBox pictureBox1;
        private MenuStrip menuStripSIS;
        private ToolStripMenuItem studentToolStripMenuItem;
        private ToolStripMenuItem courseToolStripMenuItem;
        private ToolStripMenuItem departmentToolStripMenuItem;
        private ToolStripMenuItem addStudentToolStripMenuItem;
        private ToolStripMenuItem editRemoveStudentToolStripMenuItem;
        private ToolStripMenuItem manageStudentToolStripMenuItem;
        private ToolStripMenuItem addNewCorseToolStripMenuItem;
        private ToolStripMenuItem editDeleteCourseToolStripMenuItem;
        private ToolStripMenuItem manageCourseToolStripMenuItem;
        private ToolStripMenuItem addGradeToStudentToolStripMenuItem;
        private ToolStripMenuItem editDeleteToolStripMenuItem;
        private ToolStripMenuItem viewAllStudentGradeToolStripMenuItem;
        private ToolStripMenuItem teacherToolStripMenuItem;
        private ToolStripMenuItem addTeacherToolStripMenuItem;
        private ToolStripMenuItem assignTeacherToCourseToolStripMenuItem;
        private ToolStripMenuItem editRemoveTeacherToolStripMenuItem;
        private ToolStripMenuItem departmentToolStripMenuItem1;
        private ToolStripMenuItem addDepartmentToolStripMenuItem;
        private ToolStripMenuItem assignCourseToDepartmentToolStripMenuItem;
        private ToolStripMenuItem manageDepartmentToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private ToolStripMenuItem exitApplicationToolStripMenuItem;
    }
}