using SIS.Models;
using SISRepository;
// the main app will have access to other projects in this solution 
namespace SIS.MainAPP
{
    // The main app will have all the event handler that will fletch data from the database
    public partial class Student : Form
    { 

        StudentRepo stuRepo = new StudentRepo();
        public Student()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadStudent();
        }

        // This Method will return all the list of the all the 
        private void loadStudent()
        {
            dataGridViewStudent.DataSource = null;
            dataGridViewStudent.DataSource = stuRepo.GetAllStudent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            Models.Student sdnt = new Models.Student();
            sdnt.fName = textBoxFirstName.Text;
            sdnt.lName = textBoxLastName.Text;
            sdnt.dob = textBoxdob.Text;
            sdnt.phone = textBoxContact_num.Text;
            sdnt.address = richTextBoxAddress.Text;

            stuRepo.AddStudent(sdnt);
            
            loadStudent();
        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void departmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
           throw new  NotImplementedException();
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            loadStudent();
        }
        // This item click will close the application 
        private void exitApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }


        // All these not been implimented hence as a good practice throw Not Implimented Exception
        private void editRemoveStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void manageStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void addNewCorseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void editDeleteCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void manageCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void addGradeToStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void editDeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void viewAllStudentGradeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void addTeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void assignTeacherToCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void editRemoveTeacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void addDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void assignCourseToDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void manageDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}