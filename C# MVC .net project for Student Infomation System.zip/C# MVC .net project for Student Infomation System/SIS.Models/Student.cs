﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// This project have access to the SIS model 
namespace SIS.Models
{
    public class Student
    {
        //Class library model with Student class 
        public string? fName { get; set; }
        public string? lName { get; set; }
        public string? dob { get; set; }
        public string? phone { get; set; }
        public string? address { get; set; }

    }
}
